export const DOMAIN_IMAGES = {
  technology: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=800&q=80',
  business: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
  sports: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80',
  entertainment: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
  health: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=800&q=80',
  science: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=800&q=80',
};

function ensureDetailedMatter(newsArray) {
  return newsArray.map(item => {
    if (!item.extendedContent) item.extendedContent = {};
    if (!item.extendedContent.detailedMatter || item.extendedContent.detailedMatter.trim() === '') {
      item.extendedContent.detailedMatter = 'More information coming soon.';
    }
    return item;
  });
}

const demoComments = [
  { user: 'Alice', text: 'Great article!', date: '2024-06-01' },
  { user: 'Bob', text: 'Very informative.', date: '2024-06-02' },
];

export const demoData = {
  technology: ensureDetailedMatter([
    {
      id: 1,
      title: 'Major Breakthrough in Quantum Computing',
      description: 'Scientists achieve new milestone in quantum computing research',
      image: {
        url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
        caption: 'Quantum computer in a research lab.'
      },
      category: 'Technology',
      author: 'Dr. Alice Quantum',
      publishedAt: '2024-06-01',
      source: 'Science Daily',
      tags: ['Quantum Computing', 'Research', 'Innovation'],
      url: 'https://sciencedaily.com/quantum-breakthrough',
      location: 'MIT, USA',
      language: 'English',
      readingTime: '4 min read',
      relatedLinks: [
        { title: 'Quantum Computing Explained', url: 'https://example.com/quantum-explained' }
      ],
      video: 'https://www.youtube.com/embed/QuR969uMICM',
      comments: demoComments,
      rating: { average: 4.5, count: 12 },
      extendedContent: {
        detailedMatter: 'A new breakthrough in quantum computing has helped scientists achieve a new milestone. This technology could make future computers much more powerful.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
            caption: 'Quantum computer in a research lab.'
          },
          {
            url: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=800&q=80',
            caption: 'Researchers working on quantum algorithms.'
          }
        ]
      }
    },
    {
      id: 2,
      title: 'AI Development Reaches New Heights',
      description: 'Artificial intelligence systems show unprecedented capabilities',
      image: {
        url: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
        caption: 'AI-powered robot with digital interface.'
      },
      category: 'Technology',
      author: 'Prof. Bob AI',
      publishedAt: '2024-06-02',
      source: 'AI News',
      tags: ['AI', 'Machine Learning'],
      url: 'https://ainews.com/ai-development',
      location: 'Stanford, USA',
      language: 'English',
      readingTime: '3 min read',
      relatedLinks: [
        { title: 'The Rise of AI', url: 'https://example.com/rise-of-ai' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.2, count: 8 },
      extendedContent: {
        detailedMatter: 'Recent developments in artificial intelligence have shown remarkable progress in natural language processing and computer vision.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
            caption: 'AI-powered robot with digital interface.'
          },
          {
            url: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=800&q=80',
            caption: 'Machine learning data visualization.'
          }
        ]
      }
    },
    {
      id: 8,
      title: 'Tech Giants Announce New Partnership',
      description: 'Leading companies collaborate on next-gen technology',
      image: {
        url: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=800&q=80',
        caption: 'Executives shaking hands at a tech conference.'
      },
      category: 'Technology',
      author: 'Carol Tech',
      publishedAt: '2024-06-03',
      source: 'TechCrunch',
      tags: ['Partnership', 'Innovation'],
      url: 'https://techcrunch.com/partnership',
      location: 'San Francisco, USA',
      language: 'English',
      readingTime: '2 min read',
      relatedLinks: [
        { title: 'Tech Partnerships', url: 'https://example.com/partnerships' }
      ],
      video: 'https://www.youtube.com/embed/9bZkp7q19f0',
      comments: demoComments,
      rating: { average: 4.8, count: 5 },
      extendedContent: {
        detailedMatter: 'Tech giants have announced a new partnership to collaborate on next-generation technology solutions.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=800&q=80',
            caption: 'Executives shaking hands at a tech conference.'
          },
          {
            url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
            caption: 'Team brainstorming innovative ideas.'
          }
        ]
      }
    }
  ]),
  business: ensureDetailedMatter([
    {
      id: 3,
      title: 'Global Markets Show Strong Recovery',
      description: 'Stock markets worldwide demonstrate positive trends',
      image: {
        url: 'https://images.unsplash.com/photo-1556740772-1a741367b93e?auto=format&fit=crop&w=800&q=80',
        caption: 'Stock market tickers and financial data.'
      },
      category: 'Business',
      author: 'Jane Market',
      publishedAt: '2024-06-03',
      source: 'Market Watch',
      tags: ['Stocks', 'Finance', 'Recovery'],
      url: 'https://marketwatch.com/global-recovery',
      location: 'London, UK',
      language: 'English',
      readingTime: '5 min read',
      relatedLinks: [
        { title: 'Stock Market Basics', url: 'https://example.com/stock-basics' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.0, count: 10 },
      extendedContent: {
        detailedMatter: 'Global financial markets are showing signs of strong recovery, with major indices reaching new heights.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1556740772-1a741367b93e?auto=format&fit=crop&w=800&q=80',
            caption: 'Stock market tickers and financial data.'
          },
          {
            url: 'https://images.unsplash.com/photo-1444653614773-995cb1ef9efa?auto=format&fit=crop&w=800&q=80',
            caption: 'Business people analyzing market trends.'
          }
        ]
      }
    },
    {
      id: 9,
      title: 'Startup Raises Record Funding',
      description: 'A new startup secures major investment',
      image: {
        url: 'https://images.unsplash.com/photo-1461344577544-4e5dc9487184?auto=format&fit=crop&w=800&q=80',
        caption: 'Startup team celebrating a funding milestone.'
      },
      category: 'Business',
      author: 'Sam Startup',
      publishedAt: '2024-06-04',
      source: 'Forbes',
      tags: ['Startup', 'Investment'],
      url: 'https://forbes.com/startup-funding',
      location: 'New York, USA',
      language: 'English',
      readingTime: '3 min read',
      relatedLinks: [
        { title: 'Startup Success', url: 'https://example.com/startup-success' }
      ],
      video: 'https://www.youtube.com/embed/3JZ_D3ELwOQ',
      comments: demoComments,
      rating: { average: 4.7, count: 7 },
      extendedContent: {
        detailedMatter: 'A new startup has raised record funding, attracting attention from major investors.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1461344577544-4e5dc9487184?auto=format&fit=crop&w=800&q=80',
            caption: 'Startup team celebrating a funding milestone.'
          },
          {
            url: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=800&q=80',
            caption: 'Entrepreneurs pitching to investors.'
          }
        ]
      }
    },
    {
      id: 10,
      title: 'Business Leaders Meet for Summit',
      description: 'Annual summit brings together top executives',
      image: {
        url: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80',
        caption: 'Executives networking at a business summit.'
      },
      category: 'Business',
      author: 'Eve Executive',
      publishedAt: '2024-06-05',
      source: 'Business Insider',
      tags: ['Summit', 'Leadership'],
      url: 'https://businessinsider.com/summit',
      location: 'Dubai, UAE',
      language: 'English',
      readingTime: '4 min read',
      relatedLinks: [
        { title: 'Leadership Tips', url: 'https://example.com/leadership' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.3, count: 6 },
      extendedContent: {
        detailedMatter: 'Business leaders from around the world meet for the annual summit to discuss the future of the industry.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80',
            caption: 'Executives networking at a business summit.'
          },
          {
            url: 'https://images.unsplash.com/photo-1463453091185-61582044d556?auto=format&fit=crop&w=800&q=80',
            caption: 'Panel discussion at the summit.'
          }
        ]
      }
    }
  ]),
  sports: ensureDetailedMatter([
    {
      id: 4,
      title: 'Championship Finals Set for Next Week',
      description: 'Top teams prepare for the ultimate showdown',
      image: {
        url: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80',
        caption: 'Soccer players in action during a match.'
      },
      category: 'Sports',
      author: 'Mike Sportsman',
      publishedAt: '2024-06-04',
      source: 'Sports Weekly',
      tags: ['Championship', 'Teams', 'Finals'],
      url: 'https://sportsweekly.com/championship-finals',
      location: 'Madrid, Spain',
      language: 'English',
      readingTime: '2 min read',
      relatedLinks: [
        { title: 'Finals Preview', url: 'https://example.com/finals-preview' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.6, count: 9 },
      extendedContent: {
        detailedMatter: 'The stage is set for an epic championship final between the top teams in the league.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80',
            caption: 'Soccer players in action during a match.'
          },
          {
            url: 'https://images.unsplash.com/photo-1505843273132-b09e9c9f4a2d?auto=format&fit=crop&w=800&q=80',
            caption: 'A packed stadium for the finals.'
          }
        ]
      }
    },
    {
      id: 11,
      title: 'Star Player Announces Retirement',
      description: 'Legendary athlete retires after a stellar career',
      image: {
        url: 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=800&q=80',
        caption: 'A star athlete waving goodbye to fans.'
      },
      category: 'Sports',
      author: 'Tina Athlete',
      publishedAt: '2024-06-05',
      source: 'ESPN',
      tags: ['Retirement', 'Athlete'],
      url: 'https://espn.com/retirement',
      location: 'Paris, France',
      language: 'English',
      readingTime: '3 min read',
      relatedLinks: [
        { title: 'Career Highlights', url: 'https://example.com/career-highlights' }
      ],
      video: 'https://www.youtube.com/embed/2Vv-BfVoq4g',
      comments: demoComments,
      rating: { average: 4.9, count: 15 },
      extendedContent: {
        detailedMatter: 'The legendary athlete has announced retirement after a stellar career, leaving fans emotional.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=800&q=80',
            caption: 'A star athlete waving goodbye to fans.'
          },
          {
            url: 'https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=800&q=80',
            caption: 'Press conference after retirement announcement.'
          }
        ]
      }
    },
    {
      id: 12,
      title: 'Underdog Team Makes History',
      description: 'Unexpected victory stuns the sports world',
      image: {
        url: 'https://images.unsplash.com/photo-1505843273132-b09e9c9f4a2d?auto=format&fit=crop&w=800&q=80',
        caption: 'Fans in a stadium celebrating an underdog victory.'
      },
      category: 'Sports',
      author: 'Gary Underdog',
      publishedAt: '2024-06-06',
      source: 'Sports Illustrated',
      tags: ['Underdog', 'Victory'],
      url: 'https://sportsillustrated.com/underdog',
      location: 'Sydney, Australia',
      language: 'English',
      readingTime: '2 min read',
      relatedLinks: [
        { title: 'Underdog Stories', url: 'https://example.com/underdog-stories' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.4, count: 7 },
      extendedContent: {
        detailedMatter: 'An underdog team has made history with an unexpected victory, stunning the sports world.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1505843273132-b09e9c9f4a2d?auto=format&fit=crop&w=800&q=80',
            caption: 'Fans in a stadium celebrating an underdog victory.'
          },
          {
            url: 'https://images.unsplash.com/photo-1462072219439-97e7d1a2b7a0?auto=format&fit=crop&w=800&q=80',
            caption: 'Underdog team celebrating a historic win.'
          }
        ]
      }
    }
  ]),
  entertainment: ensureDetailedMatter([
    {
      id: 5,
      title: 'New Blockbuster Movie Breaks Records',
      description: 'Latest film release sets new box office records',
      image: {
        url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
        caption: 'Red carpet at a movie premiere.'
      },
      category: 'Entertainment',
      author: 'Linda Star',
      publishedAt: '2024-06-05',
      source: 'Movie Buzz',
      tags: ['Movies', 'Box Office', 'Records'],
      url: 'https://moviebuzz.com/blockbuster-breaks-records',
      location: 'Hollywood, USA',
      language: 'English',
      readingTime: '3 min read',
      relatedLinks: [
        { title: 'Top 10 Movies', url: 'https://example.com/top10-movies' }
      ],
      video: 'https://www.youtube.com/embed/6Dh-RL__uN4',
      comments: demoComments,
      rating: { average: 4.7, count: 13 },
      extendedContent: {
        detailedMatter: 'The latest blockbuster movie has broken all previous box office records, becoming the highest-grossing film of the year.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
            caption: 'Red carpet at a movie premiere.'
          },
          {
            url: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=800&q=80',
            caption: 'Audience enjoying a film in a theater.'
          }
        ]
      }
    },
    {
      id: 13,
      title: 'Music Festival Draws Huge Crowds',
      description: 'Annual festival attracts music lovers from around the world',
      image: {
        url: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=800&q=80',
        caption: 'Crowd at a music festival.'
      },
      category: 'Entertainment',
      author: 'DJ Melody',
      publishedAt: '2024-06-06',
      source: 'Billboard',
      tags: ['Music', 'Festival'],
      url: 'https://billboard.com/music-festival',
      location: 'Ibiza, Spain',
      language: 'English',
      readingTime: '2 min read',
      relatedLinks: [
        { title: 'Festival Guide', url: 'https://example.com/festival-guide' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.5, count: 8 },
      extendedContent: {
        detailedMatter: 'The annual music festival has drawn huge crowds, making it one of the most popular events of the year.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=800&q=80',
            caption: 'Crowd at a music festival.'
          },
          {
            url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
            caption: 'Stage lights and performers.'
          }
        ]
      }
    },
    {
      id: 14,
      title: 'TV Series Finale Shocks Fans',
      description: 'Unexpected ending leaves viewers talking',
      image: {
        url: 'https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=800&q=80',
        caption: 'Cast of the TV series at the finale event.'
      },
      category: 'Entertainment',
      author: 'Sam Showrunner',
      publishedAt: '2024-06-07',
      source: 'TV Guide',
      tags: ['TV', 'Finale'],
      url: 'https://tvguide.com/series-finale',
      location: 'Los Angeles, USA',
      language: 'English',
      readingTime: '3 min read',
      relatedLinks: [
        { title: 'Series Recap', url: 'https://example.com/series-recap' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.3, count: 6 },
      extendedContent: {
        detailedMatter: 'The finale of the popular TV series shocked fans with its unexpected ending.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=800&q=80',
            caption: 'Cast of the TV series at the finale event.'
          },
          {
            url: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=800&q=80',
            caption: 'Fans reacting to the finale.'
          }
        ]
      }
    }
  ]),
  health: ensureDetailedMatter([
    {
      id: 6,
      title: 'Medical Breakthrough in Cancer Research',
      description: 'Scientists discover promising new treatment approach',
      image: {
        url: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=800&q=80',
        caption: 'Scientist working in a cancer research lab.'
      },
      category: 'Health',
      author: 'Dr. Health Wise',
      publishedAt: '2024-06-06',
      source: 'Health News',
      tags: ['Cancer', 'Research', 'Medicine'],
      url: 'https://healthnews.com/cancer-breakthrough',
      location: 'Berlin, Germany',
      language: 'English',
      readingTime: '4 min read',
      relatedLinks: [
        { title: 'Cancer Research Updates', url: 'https://example.com/cancer-updates' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.8, count: 11 },
      extendedContent: {
        detailedMatter: 'A groundbreaking discovery in cancer research has led to the development of a new treatment approach with promising results.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=800&q=80',
            caption: 'Scientist working in a cancer research lab.'
          },
          {
            url: 'https://images.unsplash.com/photo-1519864600265-abb23847ef2c?auto=format&fit=crop&w=800&q=80',
            caption: 'Microscope and lab equipment.'
          }
        ]
      }
    },
    {
      id: 15,
      title: 'Fitness Trends for 2024',
      description: 'New fitness trends are emerging worldwide',
      image: {
        url: 'https://images.unsplash.com/photo-1519864600265-abb23847ef2c?auto=format&fit=crop&w=800&q=80',
        caption: 'People exercising in a modern gym.'
      },
      category: 'Health',
      author: 'Fit Guru',
      publishedAt: '2024-06-07',
      source: 'Fitness Today',
      tags: ['Fitness', 'Trends'],
      url: 'https://fitnesstoday.com/trends-2024',
      location: 'Tokyo, Japan',
      language: 'English',
      readingTime: '2 min read',
      relatedLinks: [
        { title: 'Fitness Tips', url: 'https://example.com/fitness-tips' }
      ],
      video: 'https://www.youtube.com/embed/5qap5aO4i9A',
      comments: demoComments,
      rating: { average: 4.6, count: 7 },
      extendedContent: {
        detailedMatter: 'Fitness trends for 2024 are focusing on holistic health and technology integration.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1519864600265-abb23847ef2c?auto=format&fit=crop&w=800&q=80',
            caption: 'People exercising in a modern gym.'
          },
          {
            url: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=800&q=80',
            caption: 'Wearable fitness technology.'
          }
        ]
      }
    },
    {
      id: 16,
      title: 'Mental Health Awareness Rises',
      description: 'More people are seeking help for mental health issues',
      image: {
        url: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=800&q=80',
        caption: 'Mental health support group meeting.'
      },
      category: 'Health',
      author: 'Dr. Mind Care',
      publishedAt: '2024-06-08',
      source: 'Mind Matters',
      tags: ['Mental Health', 'Awareness'],
      url: 'https://mindmatters.com/awareness',
      location: 'Toronto, Canada',
      language: 'English',
      readingTime: '3 min read',
      relatedLinks: [
        { title: 'Mental Health Resources', url: 'https://example.com/mental-health' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.5, count: 5 },
      extendedContent: {
        detailedMatter: 'Awareness about mental health is rising, with more people seeking help and support.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=crop&w=800&q=80',
            caption: 'Mental health support group meeting.'
          },
          {
            url: 'https://images.unsplash.com/photo-1519864600265-abb23847ef2c?auto=format&fit=crop&w=800&q=80',
            caption: 'Therapist and patient in a counseling session.'
          }
        ]
      }
    }
  ]),
  science: ensureDetailedMatter([
    {
      id: 7,
      title: 'Space Mission Discovers New Planet',
      description: 'Astronomers find potentially habitable exoplanet',
      image: {
        url: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=800&q=80',
        caption: 'Spacecraft capturing images of a new planet.'
      },
      category: 'Science',
      author: 'Dr. Stella Space',
      publishedAt: '2024-06-07',
      source: 'Astronomy Now',
      tags: ['Space', 'Exoplanet', 'Discovery'],
      url: 'https://astronomynow.com/new-planet',
      location: 'Cape Canaveral, USA',
      language: 'English',
      readingTime: '5 min read',
      relatedLinks: [
        { title: 'Exoplanet Discoveries', url: 'https://example.com/exoplanets' }
      ],
      video: 'https://www.youtube.com/embed/21X5lGlDOfg',
      comments: demoComments,
      rating: { average: 4.9, count: 14 },
      extendedContent: {
        detailedMatter: 'A new space mission has discovered a potentially habitable planet orbiting a distant star.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=800&q=80',
            caption: 'Spacecraft capturing images of a new planet.'
          },
          {
            url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
            caption: 'Astronomers analyzing data in a control room.'
          }
        ]
      }
    },
    {
      id: 17,
      title: 'Breakthrough in Renewable Energy',
      description: 'Scientists develop new efficient solar panels',
      image: {
        url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
        caption: 'Solar panels in a field.'
      },
      category: 'Science',
      author: 'Dr. Green Energy',
      publishedAt: '2024-06-08',
      source: 'Nature Energy',
      tags: ['Renewable', 'Solar'],
      url: 'https://nature.com/renewable-breakthrough',
      location: 'Berlin, Germany',
      language: 'English',
      readingTime: '4 min read',
      relatedLinks: [
        { title: 'Solar Power Advances', url: 'https://example.com/solar-power' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.7, count: 9 },
      extendedContent: {
        detailedMatter: 'A breakthrough in renewable energy has led to the development of highly efficient solar panels.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
            caption: 'Solar panels in a field.'
          },
          {
            url: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=800&q=80',
            caption: 'Scientists testing solar panel efficiency.'
          }
        ]
      }
    },
    {
      id: 18,
      title: 'Deep Sea Exploration Reveals New Species',
      description: 'Marine biologists discover previously unknown life forms',
      image: {
        url: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=800&q=80',
        caption: 'Submarine exploring the deep sea.'
      },
      category: 'Science',
      author: 'Dr. Ocean Blue',
      publishedAt: '2024-06-09',
      source: 'Marine Science',
      tags: ['Ocean', 'Exploration'],
      url: 'https://marinescience.com/deep-sea',
      location: 'Pacific Ocean',
      language: 'English',
      readingTime: '3 min read',
      relatedLinks: [
        { title: 'Deep Sea Discoveries', url: 'https://example.com/deep-sea' }
      ],
      video: '',
      comments: demoComments,
      rating: { average: 4.6, count: 6 },
      extendedContent: {
        detailedMatter: 'Deep sea exploration has revealed new species, expanding our understanding of marine life.',
        photos: [
          {
            url: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=800&q=80',
            caption: 'Submarine exploring the deep sea.'
          },
          {
            url: 'https://images.unsplash.com/photo-1519864600265-abb23847ef2c?auto=format&fit=crop&w=800&q=80',
            caption: 'Marine biologists examining new species.'
          }
        ]
      }
    }
  ])
}; 