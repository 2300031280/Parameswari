import { useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  Container,
  Typography,
  Box,
  Button,
  Grid,
  Chip,
  IconButton,
  Card,
  CardContent,
  CardMedia,
  Tooltip,
} from '@mui/material';
import {
  Share,
  BookmarkBorder,
  AccessTime,
  Person,
  CalendarToday,
  ArrowBack,
  Star,
  ExpandMore,
  ExpandLess,
  Comment,
  VideoLibrary,
  Label,
} from '@mui/icons-material';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { demoData } from '../data/newsData';
import React, { useState } from 'react';

const StyledContainer = styled(Container)`
  padding-top: 2rem;
  padding-bottom: 4rem;
`;

const MediaImage = styled(motion.img)`
  width: 100%;
  height: 400px;
  object-fit: cover;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
`;

const ActionButton = styled(IconButton)`
  margin: 0 8px;
  background: rgba(0, 0, 0, 0.05);
  &:hover {
    background: rgba(0, 0, 0, 0.1);
  }
`;

const RelatedCard = styled(Card)`
  height: 100%;
  display: flex;
  flex-direction: column;
  transition: transform 0.3s ease;
  &:hover {
    transform: translateY(-5px);
  }
`;

const CollapsibleSection = ({ title, icon, children, defaultOpen = false }) => {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <Box sx={{ mb: 3 }}>
      <Button
        startIcon={icon}
        endIcon={open ? <ExpandLess /> : <ExpandMore />}
        onClick={() => setOpen(o => !o)}
        sx={{ mb: 1, textTransform: 'none' }}
      >
        {title}
      </Button>
      {open && <Box sx={{ pl: 2 }}>{children}</Box>}
    </Box>
  );
};

const NewsDetail = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const params = useParams();

  // Try to get news from navigation state, otherwise fallback to demoData by ID
  let news = location.state?.news;
  if (!news && params.id) {
    // Search all categories for the news item with this ID
    for (const category in demoData) {
      const found = demoData[category].find(n => String(n.id) === String(params.id));
      if (found) {
        news = found;
        break;
      }
    }
  }

  if (!news) {
    return (
      <StyledContainer>
        <Typography variant="h5">No news data found.</Typography>
        <Button variant="contained" sx={{ mt: 2 }} onClick={() => navigate(-1)}>
          Back
        </Button>
      </StyledContainer>
    );
  }

  // Get related articles from the same category
  const relatedArticles = demoData[news.category.toLowerCase()]?.filter(
    article => article.id !== news.id
  ).slice(0, 3) || [];

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: news.title,
        text: news.description,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      // You can add a toast notification here
    }
  };

  const [commentInput, setCommentInput] = useState('');
  const [comments, setComments] = useState(news.comments || []);
  const [userRating, setUserRating] = useState(null);
  const [showTagFilter, setShowTagFilter] = useState(null);

  const handleAddComment = () => {
    if (commentInput.trim()) {
      setComments([
        ...comments,
        { user: 'You', text: commentInput, date: new Date().toISOString().slice(0, 10) }
      ]);
      setCommentInput('');
    }
  };

  const handleTagClick = (tag) => {
    setShowTagFilter(tag);
  };

  const handleRating = (val) => {
    setUserRating(val);
  };

  const PLACEHOLDER_URL = 'https://via.placeholder.com/800x600?text=Image+Unavailable';

  return (
    <StyledContainer maxWidth="lg">
      <Button
        startIcon={<ArrowBack />}
        variant="outlined"
        sx={{ mb: 3 }}
        onClick={() => navigate(-1)}
      >
        Back to News
      </Button>

      <Grid container spacing={4}>
        <Grid item xs={12} md={8}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Typography variant="h3" gutterBottom sx={{ fontWeight: 600 }}>
              {news.title}
            </Typography>

            <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 2, mb: 2 }}>
              {news.author && (
                <Chip icon={<Person />} label={news.author} variant="outlined" size="small" />
              )}
              {news.source && (
                <Chip label={news.source} variant="outlined" size="small" />
              )}
              {news.publishedAt && (
                <Chip icon={<CalendarToday />} label={news.publishedAt} variant="outlined" size="small" />
              )}
              {news.location && (
                <Chip label={news.location} variant="outlined" size="small" />
              )}
              {news.language && (
                <Chip label={news.language} variant="outlined" size="small" />
              )}
              {news.readingTime && (
                <Chip icon={<AccessTime />} label={news.readingTime} variant="outlined" size="small" />
              )}
              {news.tags && news.tags.map(tag => (
                <Chip key={tag} label={tag} variant="outlined" size="small" />
              ))}
              {news.url && (
                <Button
                  href={news.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  size="small"
                  variant="text"
                  sx={{ ml: 2 }}
                >
                  Read Original
                </Button>
              )}
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, flexWrap: 'wrap', gap: 2 }}>
              <Chip
                icon={<Person />}
                label="John Doe"
                variant="outlined"
                size="small"
              />
              <Chip
                icon={<CalendarToday />}
                label={new Date().toLocaleDateString()}
                variant="outlined"
                size="small"
              />
              <Chip
                icon={<AccessTime />}
                label="5 min read"
                variant="outlined"
                size="small"
              />
              <Box sx={{ flexGrow: 1 }} />
              <Tooltip title="Share">
                <ActionButton onClick={handleShare}>
                  <Share />
                </ActionButton>
              </Tooltip>
              <Tooltip title="Save">
                <ActionButton>
                  <BookmarkBorder />
                </ActionButton>
              </Tooltip>
            </Box>

            {/* Ratings */}
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Star sx={{ color: '#FFD700', mr: 0.5 }} />
              <Typography variant="body1" sx={{ mr: 1 }}>
                {news.rating?.average || '-'} ({news.rating?.count || 0} ratings)
              </Typography>
              {[1,2,3,4,5].map(val => (
                <IconButton
                  key={val}
                  size="small"
                  onClick={() => handleRating(val)}
                  sx={{ color: userRating === val ? '#FFD700' : 'inherit' }}
                >
                  <Star />
                </IconButton>
              ))}
              {userRating && (
                <Typography variant="caption" sx={{ ml: 1 }}>
                  You rated: {userRating}
                </Typography>
              )}
            </Box>

            {/* Video */}
            {news.video && news.video.includes('youtube') && (
              <CollapsibleSection title="Watch Video" icon={<VideoLibrary />} defaultOpen={false}>
                <Box sx={{ my: 2 }}>
                  <iframe
                    width="100%"
                    height="315"
                    src={news.video}
                    title="News Video"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </Box>
              </CollapsibleSection>
            )}

            {/* Main Image */}
            {news.image && (
              <Box sx={{ my: 4 }}>
                <MediaImage
                  src={news.image.url || news.image}
                  alt={news.image.caption || news.title}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                />
                {news.image.caption && (
                  <Typography
                    variant="caption"
                    display="block"
                    align="center"
                    sx={{ mt: 1, color: 'text.secondary' }}
                  >
                    {news.image.caption}
                  </Typography>
                )}
              </Box>
            )}

            {/* Description */}
            <Typography variant="h6" color="text.secondary" paragraph>
              {news.description}
            </Typography>

            {/* Gallery */}
            {news.extendedContent?.photos && news.extendedContent.photos.length > 0 && (
              <CollapsibleSection title="Photo Gallery" icon={<ExpandMore />} defaultOpen={false}>
                <Grid container spacing={3}>
                  {news.extendedContent.photos.map((photo, idx) => {
                    const src = typeof photo === 'string' ? (photo.url || photo) : photo.url;
                    const caption = typeof photo === 'string' ? '' : photo.caption;
                    return (
                      <Grid item xs={12} sm={6} key={idx}>
                        <MediaImage
                          src={src}
                          alt={caption || `Related ${idx + 1}`}
                          style={{ height: '300px' }}
                        />
                        {caption && (
                          <Typography
                            variant="caption"
                            display="block"
                            align="center"
                            sx={{ mt: 1, color: 'text.secondary' }}
                          >
                            {caption}
                          </Typography>
                        )}
                      </Grid>
                    );
                  })}
                </Grid>
              </CollapsibleSection>
            )}

            {/* Detailed Matter */}
            <Typography variant="body1" paragraph sx={{ fontSize: '1.1rem', lineHeight: 1.8 }}>
              {news.extendedContent?.detailedMatter || 'More information coming soon.'}
            </Typography>

            {/* Related Links */}
            {news.relatedLinks && news.relatedLinks.length > 0 && (
              <CollapsibleSection title="Related Links" icon={<Label />} defaultOpen={false}>
                <ul style={{ paddingLeft: 20 }}>
                  {news.relatedLinks.map((link, idx) => (
                    <li key={idx}>
                      <a href={link.url} target="_blank" rel="noopener noreferrer">
                        {link.title}
                      </a>
                    </li>
                  ))}
                </ul>
              </CollapsibleSection>
            )}

            {/* Tags (clickable) */}
            <Box sx={{ mt: 2, mb: 2, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {news.tags && news.tags.map(tag => (
                <Chip
                  key={tag}
                  label={tag}
                  icon={<Label />}
                  variant={showTagFilter === tag ? 'filled' : 'outlined'}
                  color={showTagFilter === tag ? 'primary' : 'default'}
                  onClick={() => handleTagClick(tag)}
                  sx={{ cursor: 'pointer' }}
                />
              ))}
              {showTagFilter && (
                <Button size="small" onClick={() => setShowTagFilter(null)} sx={{ ml: 2 }}>
                  Clear Tag Filter
                </Button>
              )}
            </Box>

            {/* Comments Section */}
            <CollapsibleSection title="Comments" icon={<Comment />} defaultOpen={false}>
              <Box>
                {comments.length === 0 && (
                  <Typography variant="body2" color="text.secondary">No comments yet.</Typography>
                )}
                {comments.map((c, idx) => (
                  <Box key={idx} sx={{ mb: 1, pl: 1 }}>
                    <Typography variant="subtitle2">{c.user} <span style={{ color: '#888', fontSize: 12 }}>({c.date})</span></Typography>
                    <Typography variant="body2">{c.text}</Typography>
                  </Box>
                ))}
                <Box sx={{ display: 'flex', mt: 2 }}>
                  <input
                    type="text"
                    value={commentInput}
                    onChange={e => setCommentInput(e.target.value)}
                    placeholder="Add a comment..."
                    style={{ flex: 1, padding: 8, borderRadius: 4, border: '1px solid #ccc' }}
                  />
                  <Button onClick={handleAddComment} sx={{ ml: 1 }} variant="contained">Post</Button>
                </Box>
              </Box>
            </CollapsibleSection>

          </motion.div>
        </Grid>

        <Grid item xs={12} md={4}>
          <Box sx={{ position: 'sticky', top: '2rem' }}>
            <Typography variant="h5" gutterBottom sx={{ mb: 3 }}>
              Related Articles
            </Typography>
            {relatedArticles.map((article) => (
              <RelatedCard
                key={article.id}
                sx={{ mb: 2, cursor: 'pointer' }}
                onClick={() => navigate(`/news/${article.id}`, { state: { news: article } })}
              >
                <CardMedia
                  component="img"
                  height="140"
                  image={article.image?.url && article.image.url.startsWith('http') ? article.image.url : PLACEHOLDER_URL}
                  alt={article.image?.caption || article.title}
                />
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    {article.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {article.description}
                  </Typography>
                </CardContent>
              </RelatedCard>
            ))}
          </Box>
        </Grid>
      </Grid>
    </StyledContainer>
  );
};

export default NewsDetail; 