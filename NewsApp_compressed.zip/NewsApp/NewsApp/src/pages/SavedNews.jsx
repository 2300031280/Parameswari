import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Box,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
} from '@mui/material';
import {
  Search,
  Bookmark,
  Share,
  Delete,
  FilterList,
} from '@mui/icons-material';
import { motion } from 'framer-motion';
import styled from 'styled-components';
import { toast } from 'react-toastify';

const StyledCard = styled(motion(Card))`
  height: 100%;
  display: flex;
  flex-direction: column;
  transition: transform 0.3s ease-in-out;
  
  &:hover {
    transform: translateY(-5px);
  }
`;

const SavedNews = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [savedArticles, setSavedArticles] = useState([
    {
      id: 1,
      title: 'AI Breakthrough in Natural Language Processing',
      description: 'New model achieves human-level understanding...',
      image: 'https://source.unsplash.com/800x600/?technology,news&sig=21',
      category: 'Technology',
      date: 'March 15, 2024',
    },
    {
      id: 2,
      title: 'Global Climate Summit Reaches Historic Agreement',
      description: 'World leaders have agreed on unprecedented measures...',
      image: 'https://source.unsplash.com/800x600/?environment,news&sig=22',
      category: 'Environment',
      date: 'March 14, 2024',
    },
    {
      id: 3,
      title: 'New Medical Breakthrough in Cancer Research',
      description: 'Scientists have discovered a promising new treatment...',
      image: 'https://source.unsplash.com/800x600/?health,news&sig=23',
      category: 'Health',
      date: 'March 13, 2024',
    },
  ]);

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'technology', label: 'Technology' },
    { value: 'environment', label: 'Environment' },
    { value: 'health', label: 'Health' },
    { value: 'business', label: 'Business' },
    { value: 'sports', label: 'Sports' },
  ];

  const handleDelete = (id) => {
    setSavedArticles(savedArticles.filter(article => article.id !== id));
    toast.success('Article removed from saved items');
  };

  const handleShare = (article) => {
    // Implement share functionality
    toast.info('Share functionality coming soon!');
  };

  const filteredArticles = savedArticles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         article.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || article.category.toLowerCase() === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
    },
  };

  const categoryImages = {
    technology: 'https://source.unsplash.com/800x600/?technology,news',
    business: 'https://source.unsplash.com/800x600/?business,news',
    sports: 'https://source.unsplash.com/800x600/?sports,news',
    entertainment: 'https://source.unsplash.com/800x600/?entertainment,news',
    health: 'https://source.unsplash.com/800x600/?health,news',
    science: 'https://source.unsplash.com/800x600/?science,news',
    environment: 'https://source.unsplash.com/800x600/?environment,news',
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Typography variant="h3" component="h1" gutterBottom>
          Saved Articles
        </Typography>
        <Typography variant="body1" color="text.secondary" paragraph>
          Access your saved articles and manage your reading list
        </Typography>

        <Box sx={{ mb: 4, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Search saved articles..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
            sx={{ flexGrow: 1 }}
          />
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel>Category</InputLabel>
            <Select
              value={categoryFilter}
              label="Category"
              onChange={(e) => setCategoryFilter(e.target.value)}
              startAdornment={
                <InputAdornment position="start">
                  <FilterList />
                </InputAdornment>
              }
            >
              {categories.map((category) => (
                <MenuItem key={category.value} value={category.value}>
                  {category.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <Grid container spacing={3}>
            {filteredArticles.map((article) => (
              <Grid item xs={12} sm={6} md={4} key={article.id}>
                <StyledCard
                  variants={itemVariants}
                  whileHover={{ scale: 1.02 }}
                >
                  <CardMedia
                    component="img"
                    height="200"
                    image={article.image || categoryImages[article.category?.toLowerCase()] || categoryImages.technology}
                    alt={article.title}
                    onClick={() => navigate(`/news/${article.id}`)}
                    sx={{ cursor: 'pointer' }}
                  />
                  <CardContent>
                    <Chip
                      label={article.category}
                      color="primary"
                      size="small"
                      sx={{ mb: 1 }}
                    />
                    <Typography variant="h6" component="h2" gutterBottom>
                      {article.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" paragraph>
                      {article.description}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" display="block">
                      {article.date}
                    </Typography>
                    <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
                      <IconButton
                        size="small"
                        color="error"
                        onClick={() => handleDelete(article.id)}
                      >
                        <Delete />
                      </IconButton>
                      <IconButton
                        size="small"
                        onClick={() => handleShare(article)}
                      >
                        <Share />
                      </IconButton>
                    </Box>
                  </CardContent>
                </StyledCard>
              </Grid>
            ))}
          </Grid>

          {filteredArticles.length === 0 && (
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <Typography variant="h6" color="text.secondary">
                No saved articles found
              </Typography>
            </Box>
          )}
        </motion.div>
      </motion.div>
    </Container>
  );
};

export default SavedNews; 