import { useState, useEffect, lazy, Suspense } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  IconButton,
  Tabs,
  Tab,
  useTheme,
  useMediaQuery,
  CircularProgress,
  Button,
  Skeleton,
} from '@mui/material';
import { ZoomIn } from '@mui/icons-material';
import { motion, AnimatePresence } from 'framer-motion';
import styled from 'styled-components';
import { DOMAIN_IMAGES, demoData } from '../data/newsData';

// Lazy load image component
const LazyImage = lazy(() => import('../components/LazyImage'));

const StyledCard = styled(motion(Card))`
  height: 100%;
  display: flex;
  flex-direction: column;
  transition: transform 0.3s ease-in-out;
  position: relative;
  overflow: hidden;
  
  &:hover {
    transform: translateY(-5px);
    .image-overlay {
      opacity: 1;
    }
  }
`;

const ImageContainer = styled(Box)`
  position: relative;
  height: 200px;
  overflow: hidden;
  border-radius: 8px 8px 0 0;
`;

const ImageOverlay = styled(Box)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.3s ease;
`;

const CategoryHeader = styled(Box)`
  background: linear-gradient(45deg, #1976d2 30%, #42a5f5 90%);
  color: white;
  padding: 2rem;
  border-radius: 12px;
  margin-bottom: 2rem;
`;

const ReadMoreButton = styled(Button)`
  margin-top: 1rem;
  background: linear-gradient(45deg, #1976d2 30%, #42a5f5 90%);
  color: white;
  &:hover {
    background: linear-gradient(45deg, #1565c0 30%, #2196f3 90%);
  }
`;

const PLACEHOLDER_URL = 'https://via.placeholder.com/800x600?text=Image+Unavailable';

const NewsCategories = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [selectedTab, setSelectedTab] = useState(0);
  const [loading, setLoading] = useState(true);
  const [news, setNews] = useState([]);
  const [selectedImage, setSelectedImage] = useState(null);
  const [language] = useState(localStorage.getItem('newsLang') || 'en');

  const categories = ['technology', 'business', 'sports', 'entertainment', 'health', 'science'];

  useEffect(() => {
    const fetchNews = async () => {
      try {
        // Simulate API call with demo data
        await new Promise(resolve => setTimeout(resolve, 1000));
        setNews(demoData[categories[selectedTab]]);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching news:', error);
        setLoading(false);
      }
    };

    fetchNews();
  }, [selectedTab]);

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
    setLoading(true);
  };

  const handleImageClick = (image) => {
    setSelectedImage(image.url ? image : { url: image, caption: '' });
  };

  const handleCloseImage = () => {
    setSelectedImage(null);
  };

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, display: 'flex', justifyContent: 'center' }}>
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <CategoryHeader>
        <Typography variant="h4" gutterBottom>
          Latest News
        </Typography>
        <Typography variant="body1">
          Stay updated with the latest news from around the world
        </Typography>
      </CategoryHeader>

      <Tabs
        value={selectedTab}
        onChange={handleTabChange}
        variant={isMobile ? "scrollable" : "fullWidth"}
        scrollButtons={isMobile ? "auto" : false}
        sx={{ mb: 3 }}
      >
        {categories.map((category, index) => (
          <Tab key={category} label={category.charAt(0).toUpperCase() + category.slice(1)} />
        ))}
      </Tabs>

      <Grid container spacing={3}>
        {news.map((item) => {
          if (item.category === 'Sports') {
            console.log('Sports image:', item.image);
          }
          return (
            <Grid item xs={12} sm={6} md={4} key={item.id}>
              <StyledCard>
                <ImageContainer>
                  <Suspense fallback={<Skeleton variant="rectangular" height={200} />}>
                    <LazyImage
                      src={item.image?.url && item.image.url.startsWith('http') ? item.image.url : PLACEHOLDER_URL}
                      alt={item.image?.caption || item.title}
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    />
                  </Suspense>
                  <ImageOverlay className="image-overlay">
                    <IconButton onClick={() => handleImageClick(item.image?.url && item.image.url.startsWith('http') ? item.image : { url: PLACEHOLDER_URL, caption: '' })}>
                      <ZoomIn sx={{ color: 'white' }} />
                    </IconButton>
                  </ImageOverlay>
                  {item.image?.caption && (
                    <Typography
                      variant="caption"
                      display="block"
                      align="center"
                      sx={{ mt: 1, color: 'text.secondary', background: 'rgba(255,255,255,0.7)', borderRadius: 1, position: 'absolute', bottom: 0, width: '100%' }}
                    >
                      {item.image.caption}
                    </Typography>
                  )}
                </ImageContainer>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    {item.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {item.description}
                  </Typography>
                  <Box sx={{ mt: 2 }}>
                    <Chip label={item.category} size="small" />
                  </Box>
                  <ReadMoreButton
                    variant="contained"
                    onClick={() => navigate(`/news/${item.id}`)}
                    sx={{ mt: 2 }}
                  >
                    Read More
                  </ReadMoreButton>
                </CardContent>
              </StyledCard>
            </Grid>
          );
        })}
      </Grid>

      <AnimatePresence>
        {selectedImage && (
          <Box
            sx={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              bgcolor: 'rgba(0,0,0,0.9)',
              zIndex: 1300,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            onClick={handleCloseImage}
          >
            <Box>
              <img
                src={selectedImage.url || PLACEHOLDER_URL}
                alt={selectedImage.caption || 'Full size'}
                style={{
                  maxWidth: '90%',
                  maxHeight: '80vh',
                  objectFit: 'contain',
                  display: 'block',
                  margin: '0 auto',
                }}
              />
              {selectedImage.caption && (
                <Typography
                  variant="caption"
                  display="block"
                  align="center"
                  sx={{ mt: 2, color: 'white', background: 'rgba(0,0,0,0.6)', borderRadius: 1, p: 1 }}
                >
                  {selectedImage.caption}
                </Typography>
              )}
            </Box>
          </Box>
        )}
      </AnimatePresence>
    </Container>
  );
};

export default NewsCategories; 