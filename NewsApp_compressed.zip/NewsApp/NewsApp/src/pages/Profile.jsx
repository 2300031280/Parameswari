import { Container, Box, Typography, Avatar, Paper } from '@mui/material';
import { motion } from 'framer-motion';
import styled from 'styled-components';

const StyledPaper = styled(motion(Paper))`
  padding: 2.5rem;
  max-width: 400px;
  margin: 3rem auto;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 20px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.08);
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const Profile = () => {
  const email = localStorage.getItem('userEmail') || 'user@example.com';

  return (
    <Container maxWidth="sm" sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <StyledPaper
        elevation={3}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Avatar sx={{ width: 80, height: 80, mb: 2 }} />
        <Typography variant="h5" sx={{ fontWeight: 600, mb: 1 }}>
          Profile
        </Typography>
        <Box sx={{ mt: 2, width: '100%' }}>
          <Typography variant="subtitle1" color="text.secondary">
            Email
          </Typography>
          <Typography variant="body1" sx={{ fontWeight: 500 }}>
            {email}
          </Typography>
        </Box>
      </StyledPaper>
    </Container>
  );
};

export default Profile; 