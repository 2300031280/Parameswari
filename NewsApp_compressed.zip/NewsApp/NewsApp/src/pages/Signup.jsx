import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  IconButton,
  InputAdornment,
  Divider,
  Grid,
  Alert,
} from '@mui/material';
import { Visibility, VisibilityOff, ArrowBack } from '@mui/icons-material';
import { motion } from 'framer-motion';
import styled from 'styled-components';

const FullScreenContainer = styled(Container)`
  min-height: 100vh !important;
  display: flex !important;
  align-items: center;
  justify-content: center;
`;

const StyledPaper = styled(motion(Paper))`
  padding: 3rem;
  max-width: 500px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
`;

const Logo = styled(motion.div)`
  text-align: center;
  margin-bottom: 2rem;
  img {
    width: 120px;
    height: auto;
  }
`;

const Signup = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState('');
  const [step, setStep] = useState('form');
  const [verificationCode, setVerificationCode] = useState('');
  const [userInputCode, setUserInputCode] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setError('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Validation
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.password || !formData.confirmPassword) {
      setError('All fields are required.');
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    // Generate 6-digit code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setVerificationCode(code);
    setStep('verify');
  };

  const handleVerify = (e) => {
    e.preventDefault();
    if (userInputCode === verificationCode) {
      localStorage.setItem('userEmail', formData.email);
      localStorage.setItem('isLoggedIn', 'true');
      navigate('/categories');
    } else {
      setError('Incorrect verification code.');
    }
  };

  return (
    <FullScreenContainer maxWidth="sm">
      <Button
        startIcon={<ArrowBack />}
        onClick={() => navigate('/')}
        sx={{ mb: 2, alignSelf: 'flex-start', background: '#fff', color: '#1976d2', border: '1px solid #1976d2', '&:hover': { background: '#e3f0ff' } }}
      >
        Back to Home
      </Button>
      {step === 'form' ? (
        <StyledPaper
          elevation={3}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Logo
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <img src="/news-logo.png" alt="NEWS4YOU Logo" />
          </Logo>
          <Typography variant="h4" component="h1" align="center" gutterBottom sx={{ fontWeight: 600 }}>
            Create Account
          </Typography>
          <Typography variant="body1" align="center" color="textSecondary" gutterBottom>
            Sign up to access NEWS4YOU
          </Typography>
          <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
            <TextField
              fullWidth
              label="First Name"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              required
              variant="outlined"
              margin="normal"
              InputProps={{ sx: { height: 56, fontSize: '1.1rem' } }}
              InputLabelProps={{ sx: { fontSize: '1.1rem' } }}
            />
            <TextField
              fullWidth
              label="Last Name"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              required
              variant="outlined"
              margin="normal"
              InputProps={{ sx: { height: 56, fontSize: '1.1rem' } }}
              InputLabelProps={{ sx: { fontSize: '1.1rem' } }}
            />
            <TextField
              fullWidth
              label="Email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              margin="normal"
              required
              variant="outlined"
            />
            <TextField
              fullWidth
              label="Password"
              name="password"
              type={showPassword ? 'text' : 'password'}
              value={formData.password}
              onChange={handleChange}
              margin="normal"
              required
              variant="outlined"
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
            <TextField
              fullWidth
              label="Confirm Password"
              name="confirmPassword"
              type={showPassword ? 'text' : 'password'}
              value={formData.confirmPassword}
              onChange={handleChange}
              margin="normal"
              required
              variant="outlined"
            />
            {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="success"
              size="large"
              sx={{ mt: 3, mb: 2, py: 1.5, borderRadius: 2, fontWeight: 600, fontSize: '1.1rem' }}
            >
              Sign Up
            </Button>
            <Divider sx={{ my: 3 }} />
            <Box sx={{ mt: 1, textAlign: 'center' }}>
              <Typography variant="body2">
                Already have an account?{' '}
                <Link to="/login" style={{ textDecoration: 'none', color: '#1976d2', fontWeight: 500 }}>
                  Sign In
                </Link>
              </Typography>
            </Box>
          </Box>
        </StyledPaper>
      ) : (
        <StyledPaper
          elevation={3}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Typography variant="h5" gutterBottom>OTP Verification</Typography>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            Enter the 6-digit code sent to your email. (Demo code: <b>{verificationCode}</b>)
          </Typography>
          <form onSubmit={handleVerify}>
            <TextField
              label="Verification Code"
              variant="outlined"
              fullWidth
              margin="normal"
              value={userInputCode}
              onChange={e => setUserInputCode(e.target.value)}
              inputProps={{ maxLength: 6 }}
            />
            {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
            <Button type="submit" variant="contained" fullWidth sx={{ mt: 2 }}>
              Verify
            </Button>
          </form>
        </StyledPaper>
      )}
    </FullScreenContainer>
  );
};

export default Signup; 