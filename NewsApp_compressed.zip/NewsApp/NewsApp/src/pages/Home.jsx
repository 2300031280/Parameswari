import { motion } from 'framer-motion';
import { Container, Typography, Box, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { useState } from 'react';

const FullScreenContainer = styled(Container)`
  min-height: 100vh !important;
  display: flex !important;
  align-items: center;
  justify-content: center;
`;

const Logo = styled(motion.div)`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
`;

const LogoPlaceholder = styled(motion.div)`
  width: 200px;
  height: 200px;
  background: #1976d2;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 2rem;
`;

const categoryImages = {
  technology: 'https://source.unsplash.com/800x600/?technology,news',
  business: 'https://source.unsplash.com/800x600/?business,news',
  sports: 'https://source.unsplash.com/800x600/?sports,news',
  entertainment: 'https://source.unsplash.com/800x600/?entertainment,news',
  health: 'https://source.unsplash.com/800x600/?health,news',
  science: 'https://source.unsplash.com/800x600/?science,news',
  environment: 'https://source.unsplash.com/800x600/?environment,news',
};

const Home = () => {
  const navigate = useNavigate();

  const [featuredNews, setFeaturedNews] = useState({
    title: 'Breaking News: Major Development in Technology',
    description: 'A revolutionary breakthrough in artificial intelligence has been announced...',
    image: 'https://source.unsplash.com/1200x800/?technology,news&sig=1',
    category: 'Technology',
  });

  const [newsItems, setNewsItems] = useState([
    {
      id: 1,
      title: 'Global Climate Summit Reaches Historic Agreement',
      description: 'World leaders have agreed on unprecedented measures to combat climate change...',
      image: 'https://source.unsplash.com/800x600/?environment,news&sig=2',
      category: 'Environment',
    },
    {
      id: 2,
      title: 'New Medical Breakthrough in Cancer Research',
      description: 'Scientists have discovered a promising new treatment approach...',
      image: 'https://source.unsplash.com/800x600/?health,news&sig=3',
      category: 'Health',
    },
    {
      id: 3,
      title: 'Sports: Championship Finals Set for Next Week',
      description: 'The stage is set for an epic showdown between the top teams...',
      image: 'https://source.unsplash.com/800x600/?sports,news&sig=4',
      category: 'Sports',
    },
  ]);

  return (
    <FullScreenContainer maxWidth="lg">
      <Logo
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <LogoPlaceholder
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          NEWS4YOU
        </LogoPlaceholder>
        <Typography variant="h2" component="h1" gutterBottom>
          Welcome to NEWS4YOU
        </Typography>
        <Typography variant="h5" color="text.secondary" paragraph>
          Your trusted source for the latest news and updates
        </Typography>
        <Box sx={{ mt: 4, display: 'flex', gap: 2, justifyContent: 'center' }}>
          <Button
            variant="contained"
            size="large"
            onClick={() => navigate('/login')}
            sx={{ px: 4 }}
          >
            Login
          </Button>
          <Button
            variant="contained"
            size="large"
            onClick={() => navigate('/signup')}
            sx={{ px: 4 }}
          >
            Sign Up
          </Button>
        </Box>
      </Logo>
    </FullScreenContainer>
  );
};

export default Home; 