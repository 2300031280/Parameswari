import { useState, useEffect } from 'react';
import { Box, Skeleton, Typography } from '@mui/material';

const PLACEHOLDER_URL = 'https://via.placeholder.com/800x600?text=Image+Unavailable';

const LazyImage = ({ src, alt, style, onLoad }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [currentSrc, setCurrentSrc] = useState(
    src && typeof src === 'string' && src.startsWith('http') ? src : PLACEHOLDER_URL
  );

  useEffect(() => {
    const validSrc = src && typeof src === 'string' && src.startsWith('http') ? src : PLACEHOLDER_URL;
    setCurrentSrc(validSrc);
    setIsLoaded(false);
    setError(false);
    const img = new Image();
    img.src = validSrc;
    img.onload = () => {
      setIsLoaded(true);
      onLoad?.();
    };
    img.onerror = () => {
      setError(true);
      setCurrentSrc(PLACEHOLDER_URL);
    };
  }, [src, onLoad]);

  return (
    <>
      {!isLoaded && (
        <Skeleton
          variant="rectangular"
          animation="wave"
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
          }}
        />
      )}
      <img
        src={currentSrc}
        alt={alt}
        style={{
          ...style,
          opacity: isLoaded || error ? 1 : 0,
          transition: 'opacity 0.3s ease-in-out',
        }}
        onLoad={() => setIsLoaded(true)}
        onError={() => {
          if (!error) {
            setError(true);
            setCurrentSrc(PLACEHOLDER_URL);
          }
        }}
      />
      {error && (
        <Box
          sx={{
            ...style,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: '#f5f5f5',
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
          }}
        >
          <Typography variant="body2" color="text.secondary">
            Image unavailable
          </Typography>
        </Box>
      )}
    </>
  );
};

export default LazyImage; 