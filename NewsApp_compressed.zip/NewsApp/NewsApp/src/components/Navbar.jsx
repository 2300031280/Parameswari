import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Menu,
  MenuItem,
  Box,
  useTheme,
  useMediaQuery,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Avatar,
  Select,
} from '@mui/material';
import {
  Menu as MenuIcon,
  AccountCircle,
  Language,
  Bookmark,
  Mic,
} from '@mui/icons-material';
import styled from 'styled-components';

const Logo = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  img {
    height: 40px;
  }
`;

const Navbar = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const [profileAnchorEl, setProfileAnchorEl] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const navigate = useNavigate();
  const location = useLocation();

  // Simulate login state using localStorage
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem('isLoggedIn') === 'true';
  });

  const [language, setLanguage] = useState(() => localStorage.getItem('newsLang') || 'en');

  useEffect(() => {
    const handleStorage = () => {
      setIsLoggedIn(localStorage.getItem('isLoggedIn') === 'true');
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  // Hide profile/logout on /, /login, /signup
  const hideProfile =
    location.pathname === '/' ||
    location.pathname === '/login' ||
    location.pathname === '/signup';

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleProfileMenu = (event) => {
    setProfileAnchorEl(event.currentTarget);
  };

  const handleProfileClose = () => {
    setProfileAnchorEl(null);
  };

  const handleLogout = () => {
    localStorage.setItem('isLoggedIn', 'false');
    setIsLoggedIn(false);
    setProfileAnchorEl(null);
    navigate('/login');
  };

  const handleLanguageChange = (e) => {
    setLanguage(e.target.value);
    localStorage.setItem('newsLang', e.target.value);
    window.dispatchEvent(new Event('languageChange'));
  };

  const menuItems = [
    { text: 'Home', path: '/' },
    { text: 'Categories', path: '/categories' },
    { text: 'Saved News', path: '/saved' },
  ];

  const renderMobileMenu = () => (
    <Drawer
      anchor="left"
      open={mobileMenuOpen}
      onClose={() => setMobileMenuOpen(false)}
    >
      <List sx={{ width: 250 }}>
        {menuItems.map((item) => (
          <ListItem
            button
            key={item.text}
            onClick={() => {
              navigate(item.path);
              setMobileMenuOpen(false);
            }}
          >
            <ListItemText primary={item.text} />
          </ListItem>
        ))}
      </List>
    </Drawer>
  );

  return (
    <AppBar position="static">
      <Toolbar>
        {isMobile && (
          <IconButton
            edge="start"
            color="inherit"
            aria-label="menu"
            onClick={() => setMobileMenuOpen(true)}
          >
            <MenuIcon />
          </IconButton>
        )}
        <Logo>
          <img src="/news-logo.png" alt="News Logo" />
        </Logo>
        <Box sx={{ flexGrow: 1 }} />
        {!isMobile && (
          <Box sx={{ display: 'flex', gap: 2 }}>
            {menuItems.map((item) => (
              <Button
                key={item.text}
                color="inherit"
                component={Link}
                to={item.path}
              >
                {item.text}
              </Button>
            ))}
          </Box>
        )}
        <Box sx={{ display: 'flex', gap: 1 }}>
          <IconButton color="inherit" aria-label="voice control">
            <Mic />
          </IconButton>
          {/* Language Selector */}
          <Select
            value={language}
            onChange={handleLanguageChange}
            size="small"
            sx={{ ml: 1, color: 'white', bgcolor: 'rgba(25, 118, 210, 0.08)', borderRadius: 1, minWidth: 80 }}
            variant="outlined"
            disableUnderline
          >
            <MenuItem value="en">English</MenuItem>
            <MenuItem value="hi">Hindi</MenuItem>
            <MenuItem value="fr">French</MenuItem>
            <MenuItem value="es">Spanish</MenuItem>
            <MenuItem value="de">German</MenuItem>
          </Select>
          <IconButton color="inherit" aria-label="saved news">
            <Bookmark />
          </IconButton>
          {/* Profile/Logout menu after login */}
          {isLoggedIn && !hideProfile && (
            <>
              <IconButton color="inherit" onClick={handleProfileMenu} sx={{ ml: 1 }}>
                <Avatar sx={{ width: 32, height: 32 }} />
              </IconButton>
              <Menu
                anchorEl={profileAnchorEl}
                open={Boolean(profileAnchorEl)}
                onClose={handleProfileClose}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
              >
                <MenuItem onClick={handleLogout}>Logout</MenuItem>
              </Menu>
            </>
          )}
          <IconButton
            aria-label="account of current user"
            aria-controls="menu-appbar"
            aria-haspopup="true"
            onClick={handleMenu}
            color="inherit"
          >
            <AccountCircle />
          </IconButton>
        </Box>
        <Menu
          id="menu-appbar"
          anchorEl={anchorEl}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          keepMounted
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          open={Boolean(anchorEl)}
          onClose={handleClose}
        >
          <MenuItem component={Link} to="/login" onClick={handleClose}>
            Login
          </MenuItem>
          <MenuItem component={Link} to="/signup" onClick={handleClose}>
            Sign Up
          </MenuItem>
        </Menu>
        {renderMobileMenu()}
      </Toolbar>
    </AppBar>
  );
};

export default Navbar; 